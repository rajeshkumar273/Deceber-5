package com.ecommerce.application.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.application.modal.Product;

public interface add_productRepo extends JpaRepository<Product, Integer> {
	
}
