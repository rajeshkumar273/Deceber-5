package com.ecommerce.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecommerce.application.modal.admin;
import com.ecommerce.application.repo.adminRep;


@Controller
public class admin_Controller {

	@Autowired
	private adminRep admin_repo;
	
	@GetMapping("/")
	public String homeview()
	{
		return "home";
	} 

	@GetMapping("/admin_sign-up")
	public String adminView(Model model)
	{
		model.addAttribute("admin", new admin());
		return "admin_signup";
	}
	
	@PostMapping("/new_admin")
	public String newadmin(admin admin)
	{  
		admin_repo.save(admin);
		
		return "Alogin";
	}
	
	@GetMapping("/Alogin")
	public String viewALOgin()
	{
		return "Alogin";
	}
	
	@PostMapping("/aDminLo")
	public String dologin(@RequestParam("e_mail") String email,@RequestParam("password") String password)
	{
		admin admin = admin_repo.login(email, password);
		if(admin != null) {
			return "redirect:/admin";
		}
		else {
			return "redirect:/Alogin";
		}
	}
}