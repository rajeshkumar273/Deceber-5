package com.ecommerce.application.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.application.modal.category;

public interface caterepo extends JpaRepository<category, Integer> {

}
