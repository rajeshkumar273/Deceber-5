package com.ecommerce.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ecommerce.application.modal.Coupon;
import com.ecommerce.application.repo.CouponRepo;

@Controller
public class CouponController {
	
	@Autowired
	private CouponRepo Crepo;
	
	@GetMapping("/adcoupon")
	public String viewcoupon(Model model)
	{ 
		model.addAttribute("Coupon", new Coupon());
		return "coupon";
	}

	@PostMapping("/addCoup")
	public String addCoupon(Coupon coupon)
	{
		Crepo.save(coupon);
		return "saved";
	}
}
