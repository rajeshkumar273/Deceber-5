package com.ecommerce.application.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.application.modal.Event;

public interface eventRepo extends JpaRepository<Event, Integer> {

}
