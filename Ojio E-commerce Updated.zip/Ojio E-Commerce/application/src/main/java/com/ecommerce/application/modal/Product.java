package com.ecommerce.application.modal;

import javax.persistence.*;

@Entity
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productId;
	
	@Column(nullable=false,unique=true)
	private String productName;
	
	@Column(nullable=false)
	private String productprice;
	
	@Column(nullable=false)
	private String productimage;
	
	private int categoryId;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "categoryId", insertable = false, updatable = false)
	private category productCategory;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductprice() {
		return productprice;
	}

	public void setProductprice(String productprice) {
		this.productprice = productprice;
	}

	public String getProductimage() {
		return productimage;
	}

	public void setProductimage(String productimage) {
		this.productimage = productimage;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public category getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(category productCategory) {
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productprice=" + productprice
				+ ", productimage=" + productimage + ", categoryId=" + categoryId + ", productCategory="
				+ productCategory + "]";
	}

	public Product(int productId, String productName, String productprice, String productimage, int categoryId,
			category productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productprice = productprice;
		this.productimage = productimage;
		this.categoryId = categoryId;
		this.productCategory = productCategory;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	

}
