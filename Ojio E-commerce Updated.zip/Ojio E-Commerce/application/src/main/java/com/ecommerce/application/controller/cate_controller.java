package com.ecommerce.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ecommerce.application.modal.category;
import com.ecommerce.application.repo.caterepo;

@Controller
public class cate_controller {

	@Autowired
	private caterepo caterepo;
	
	@GetMapping("/admin")
	public String viewadminlogin()
	{
		return "admin";
	}

	@GetMapping("/category")
	public String viewadminpage(Model model)
	{  
		model.addAttribute("category", new category());
		return "add_Cate";
	}
	
	@PostMapping("/add_cate")
	public String addCategory(category category)
	{
		caterepo.save(category);
		return "saved";
	}
}
