package com.ecommerce.application.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Event {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eventID;
	
	@Column(nullable=false,unique=true)
	private String eventName;
	
	@Column(nullable=false)
	private String eStartDate;
	
	@Column(nullable=false)
	private String eEndDate;
	
	public int getEventID() {
		return eventID;
	}
	public void setEventID(int eventID) {
		this.eventID = eventID;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String geteStartDate() {
		return eStartDate;
	}
	public void seteStartDate(String eStartDate) {
		this.eStartDate = eStartDate;
	}
	public String geteEndDate() {
		return eEndDate;
	}
	public void seteEndDate(String eEndDate) {
		this.eEndDate = eEndDate;
	}
	public Event(int eventID, String eventName, String eStartDate, String eEndDate) {
		super();
		this.eventID = eventID;
		this.eventName = eventName;
		this.eStartDate = eStartDate;
		this.eEndDate = eEndDate;
	}
	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Event [eventID=" + eventID + ", eventName=" + eventName + ", eStartDate=" + eStartDate + ", eEndDate="
				+ eEndDate + "]";
	}
	
	
	
}
